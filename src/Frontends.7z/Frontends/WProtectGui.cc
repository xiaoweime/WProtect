#ifndef WPROTECT_USE_QT
#define WPROTECT_USE_QT
#endif

#include "../vm_protect.h" 
#include <QFileDialog>
#include <QMessageBox>
#include <QAbstractItemModel>
#include "ui_WProtectDialog.h"
#include "WProtectGui.h"
#include <list>
#include <fstream>

QListWidget * ptr_log_list;
QTreeWidget * ptr_protect_address_tree;


#define about_info "\
\
<font color=\"blue\">&#160;&#160;&#160;&#160;ReVerSe EnGiNeeR TeAm[R.E.T]<br>\
&#160;&#160;Name              -=TeaM RET Members=-        Comment <br>    \
<font color=\"red\">[ Kido....................<font color=\"red\">Founder/Admin ] <br>\
[ L4nce..................<font color=\"\">Unpacker/Coder ] <br>\
[ Rookietp...............<font color=\"\">Reverser/Coder ] <br>\
[ Sound...............<font color=\"\">Unpacker/Reverser ] <br>\
[ willj...........<font color=\"\">Vulnerability Digging ] <br>\
[ xiaoy.................<font color=\"\">Kernel Security ]<br>\
[ XiaoWei..............<font color=\"\">Reverser/Coder ]<br>\
[ yoza................<font color=\"\">Unpacker/Reverser ]<br>\
<font color=\"Gray\">Copyright &#169; 2001-2015 ReverseEngineer.Cn All Rights Reserved</font><br>\
<font color=\"Gray\"><a href=\"http://www.reverseengineer.cn/\" title=\"EnTer[R.E.T]Forum\"><b>FORUM</b></a> </font>\
\
"

WProtectGui::WProtectGui(QWidget * parent)
    :QWidget(parent),
    ui(new Ui::WProtectDialog)
{
    ui->setupUi(this);
    ptr_log_list = ui->listWidget_logOut;
    ptr_protect_address_tree = ui->treeWidget_protectAddress;
    ui->treeWidget_protectAddress->setColumnCount(1);
    ui->treeWidget_protectAddress->setHeaderLabel(tr("保护地址"));

    QMessageBox::about(this,"WProtect By XiaoWei",about_info);
}

WProtectGui::~WProtectGui()
{
    delete ui;
}

void  WProtectGui::on_pushButton_openFile_clicked()
{
    ui->treeWidget_protectAddress->clear();
    ui->listWidget_logOut->clear();
    user_protect_address.clear();
    QString fileName = QFileDialog::getOpenFileName(this,tr("Open File"),tr(""),tr("EXECUTABLE File(*.exe)"));
    if (fileName != "")
    {
        ui->lineEdit_filePath->setText(fileName);

        ifstream f;
        QString configFileName = fileName;
        configFileName.replace(tr(".exe"),tr(".wp"));
        f.open(configFileName.toStdString().c_str());
        if (f.is_open())
        {
            QMessageBox load_config_info(QMessageBox::Information,tr("配置文件"),tr("找到配置文件是否加载"),QMessageBox::Yes|QMessageBox::No,NULL) ;
            if (load_config_info.exec() != QMessageBox::No)
            {
                info("load prject config file : %s",configFileName.toStdString().c_str());
                int key;
                int value;
                while (!f.eof())
                {
                    f.read((char*)(&key),sizeof(key));

                    warn("%d",key);
                    //warn("a");
                    //f >> key >> value;
                    //user_protect_address.insert(key,value);
                }

            }
            f.close();
        }
        vm_protect vm;
        std::map<long,long> xxx = user_protect_address.toStdMap();
        vm.protect_address_disas(fileName.toStdString().c_str(),xxx);
    }
}

void  WProtectGui::on_pushButton_protect_clicked()
{
    if (ui->lineEdit_filePath->text() == "")
    {
        QMessageBox::warning(this,"警告","请选择一个要保护的文件");
        return;
    }
    ui->listWidget_logOut->clear();
    vm_protect vm;
    QString fileName = ui->lineEdit_filePath->text();
    std::map<long,long> xxx = user_protect_address.toStdMap();
    vm.protect_code(fileName.toStdString().c_str(),xxx);
    QMessageBox save_config_info(QMessageBox::Information,tr("编译成功"),tr("代码保护成功,是否保存配置文件"),QMessageBox::Yes|QMessageBox::No,NULL);
    if (save_config_info.exec() == QMessageBox::Yes)
    {
        fileName.replace(tr("\.exe"),tr(".wp"));
        ofstream f;
        f.open(fileName.toStdString().c_str(),ios_base::binary);
        if (f.is_open())
        {
            for (QMap<long,long>::iterator iter = user_protect_address.begin();
                 iter != user_protect_address.end();iter++)
            {
                warn("save key:%d",iter.key());
                warn("save value:%d",iter.value());
                f << iter.key();
                f << iter.value();
            }
            f.close();
        }
    }



}


void WProtectGui::on_listWidget_logOut_doubleClicked(const QModelIndex &index)
{
    const QAbstractItemModel * model = index.model();
    QString text = model->data(index,Qt::DisplayRole).toString();
    QString title = text;

    title.remove(QRegExp(":.+"));
    text.remove(0,text.indexOf(":",0)+1);
    QMessageBox info_msg(QMessageBox::Information,title,text);
    info_msg.exec();
}

void WProtectGui::on_pushButton_addProtectAddress_clicked()
{
    QString beginAddress = ui->lineEdit_beginAddress->text();
    QString endAddress = ui->lineEdit_endAddress->text();
    if (beginAddress == "" || endAddress == "")
    {
        QMessageBox::warning(this,"警告","请输入正确地址");
        return;
    }
    user_protect_address.insert(beginAddress.toLong(0,16),endAddress.toLong(0,16));
    vm_protect vm;
    std::map<long,long> xxx;
    xxx = user_protect_address.toStdMap();
    vm.protect_address_disas(ui->lineEdit_filePath->text().toStdString().c_str(),xxx);
}


void WProtectGui::on_pushButton_about_clicked()
{
    //QMessageBox::about(this,"WProtect","WProtect是一个虚拟机保护软件\n详情请关注 http://release.crack4r.cc/TeaM.RET.html");
    QMessageBox::about(this,"WProtect By XiaoWei",about_info);
}
